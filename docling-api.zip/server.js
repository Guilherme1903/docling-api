import express from 'express';
import fileUpload from 'express-fileupload';
import { TextGrid } from 'docling';

const app = express();
app.use(fileUpload());

app.post('/parse', async (req, res) => {
  try {
    if (!req.files?.file) {
      return res.status(400).send({ error: 'Arquivo não enviado' });
    }
    const text = req.files.file.data.toString('utf-8');
    const tg = new TextGrid(text);
    res.json(tg.toJSON());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(3000, () => console.log('Docling API rodando na porta 3000'));